<?php
$db=new PDO('mysql:host=localhost;dbname=pro_bbms','root','');

?>