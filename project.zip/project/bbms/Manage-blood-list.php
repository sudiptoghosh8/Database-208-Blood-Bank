<?php
include('connection.php');
session_start();

?>

<!DOCTYPE html>
<html>
<head>
	<title>Manage Blood List</title>
	
	<style type="text/css">
			#header
{
	width: 100%;
	height: 50px;
	background-color: blue;
	color: white;
}

#footer{
	width: 100%;
	height: 70px;
	background-color: blue;
	color: white;
}
		td{
			width: 200px;
			height: 40px;
			background-color: olive;
			color: white;
		}
	</style>
</head>
<body>
<div id="full">
	<div id="inner_full">
		<div id="header"><h2 align="center"><a href="admin-home.php" style="text-decoration: none;color: white;">Blood Bank Management System</a></h2></div>
		<div id="body">
			<br>
			<?php
			$un=$_SESSION['un'];
			if(!$un)
			{
				header("Location:index.php");
			}
			?>

			 <h1>Donor List</h1>
			 <center><div id="form">
			 	<table>
			 		<tr>
			 			<td><center><b><font color="black">ID</font></b></center></td>
			 			<td><center><b><font color="black">Name</font></b></center></td>
			 			<td><center><b><font color="black">Father's Name</font></b></center></td>
			 			<td><center><b><font color="black">Address</font></b></center></td>
			 			<td><center><b><font color="black">City</font></b></center></td>
			 			<td><center><b><font color="black">Age</font></b></center></td>
			 			<td><center><b><font color="black">Blood Group</font></b></center></td>
			 			<td><center><b><font color="black">Email</font></b></center></td>
			 			<td><center><b><font color="black">Mobile No</font></b></center></td>
			 			<td><center><b><font color="black">Delete</font></b></center></td>
			 			<td><center><b><font color="black">Update</font></b></center></td>
			 		</tr>

			 		<?php
			 		 include 'conn.php'; 


			 		$q = "select * from donor_registration ";
 				$query = mysqli_query($con,$q);
					 while($res = mysqli_fetch_array($query)){
			 			?>
			 		<tr>
			 			<td><center><?php echo $res['id']; ?></center></td>
			 			<td><center><?php echo $res['name']; ?></center></td>
			 			<td><center><?php echo $res['fname']; ?></center></td>
			 			<td><center><?php echo $res['address']; ?></center></td>
			 			<td><center><?php echo $res['city']; ?></center></td>
			 			<td><center><?php echo $res['age']; ?></center></td>
			 			<td><center><?php echo $res['bgroup']; ?></center></td>
			 			<td><center><?php echo $res['email']; ?></center></td>
			 			<td><center><?php echo $res['mno']; ?></center></td>
			 			<td> <button class="btn-danger btn"> <a href="delete.php?id=<?php echo $res['id']; ?>" class="text-white">Delete </a>  </button> </td>
 <td> <button class="btn-primary btn"> <a href="update.php?id=<?php echo $res['id']; ?>" class="text-white">Update </a> </button> </td>
			 			
			 		</tr>
			 		
			 			
			 		
			 		
			 		<?php

			 		}
			 		?>
			 		

			 		
			 	</table>
			 </div></center>

		</div>
		<div id="footer"><h4 align="center">Copyright@ourproject</h4>
<p align="center"><a href="logout.php"><font color="white">Logout</font></a></p>
		</div>


	</div>
</div>
</body>
</html>