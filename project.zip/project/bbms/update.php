<?php

 include 'conn.php';
session_start();
 if(isset($_POST['sub'])){

$id = $_GET['id'];
$name=$_POST['name'];
$fname=$_POST['fname'];
$address=$_POST['address'];
$city=$_POST['city'];
$age=$_POST['age'];
$bgroup=$_POST['bgroup'];
$email=$_POST['email'];
$mno=$_POST['mno'];
$q ="update donor_registration set id=$id, name='$name',fname='$fname',address='$address',city='$city', age='$age',bgroup='$bgroup',email='$email',mno='$mno' where id=$id " ;

 $query = mysqli_query($con,$q);

 header('location:Manage-blood-list.php');
 }

?>



<!DOCTYPE html>
<html>
<head>
	<title>Donor Details Update</title>
	<link rel="stylesheet" type="text/css" href="css/s1.css">
</head>
<body>
<div id="full">
	<div id="inner_full">
		<div id="header"><h2 align="center"><a href="admin-home.php" style="text-decoration: none;color: white;">Blood Bank Management System</a></h2></div>
		<div id="body">
			<br>
			<?php
			$un=$_SESSION['un'];
			if(!$un)
			{
				header("Location:index.php");
			}
			?>

			 <h1>Donor Details Update</h1>
			 <center><div id="form">
			 	<form action="" method="post">
			 	<table>
			 		<tr>
			 			<td width="200px" height="50px">
			 				Enter Name
			 			</td>
			 			<td width="200px" height="50px"><input type="text" name="name" placeholder="Enter Name"></td>

			 			<td width="200px" height="50px">
			 				Enter Father's Name
			 			</td>
			 			<td width="200px" height="50px"><input type="text" name="fname" placeholder="Enter Father Name"></td>

			 		</tr>


			 		<tr>
			 			<td width="200px" height="50px">
			 				Enter Address
			 			</td>
			 			<td width="200px" height="50px"><textarea name="address"></textarea></td>

			 			<td width="200px" height="50px">
			 				Enter City
			 			</td>
			 			<td width="200px" height="50px"><input type="text" name="city" placeholder="Enter City"></td>

			 		</tr>


			 		<tr>
			 			<td width="200px" height="50px">
			 				Enter Age
			 			</td>
			 			<td width="200px" height="50px"><input type="text" name="age" placeholder="Enter Age"></td>

			 			<td width="200px" height="50px">
			 				Select Blood Group
			 			</td>
			 			<td width="200px" height="50px">
			 				<select name="bgroup">
			 					<option>O+</option>
			 					<option>O-</option>
			 					<option>AB+</option>
			 					<option>AB-</option>
			 					<option>B+</option>
			 					<option>B-</option>
			 					<option>A+</option>
			 					<option>A-</option>
			 				</select>
			 			</td>
			 		</tr>


			 		<tr>
			 			<td width="200px" height="50px">
			 				Enter E-Mail
			 			</td>
			 			<td width="200px" height="50px"><input type="text" name="email" placeholder="Enter E-Mail"></td>

			 			<td width="200px" height="50px">
			 				Enter Mobile No
			 			</td>
			 			<td width="200px" height="50px"><input type="text" name="mno" placeholder="Enter Mobile No"></td>

			 		</tr>

			 		<tr>
			 			<td>
			 				<input type="submit" name="sub" value="save">
			 			</td>
			 		</tr>


			 	</table>
			 	</form>

			 </div></center>

		</div>
		<div id="footer"><h4 align="center">Copyright@ourproject</h4>
<p align="center"><a href="logout.php"><font color="white">Logout</font></a></p>
		</div>


	</div>
</div>
</body>
</html>