<?php

include 'conn.php';
$id = $_GET['id'];
$q = "DELETE FROM `donor_registration` WHERE id = $id ";
mysqli_query($con, $q);
header('location:Manage-blood-list.php');

?>