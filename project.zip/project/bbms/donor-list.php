<?php
include('connection.php');
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Donor List</title>

	<style type="text/css">
			#header
{
	width: 100%;
	height: 50px;
	background-color: blue;
	color: white;
}

#footer{
	width: 100%;
	height: 70px;
	background-color: blue;
	color: white;
}
		td{
			width: 200px;
			height: 40px;
			background-color: olive;
			color: white;
		}
	</style>
</head>
<body>
<div id="full">
	<div id="inner_full">
		<div id="header"><h2 align="center"><a href="admin-home.php" style="text-decoration: none;color: white;">Blood Bank Management System</a></h2></div>
		<div id="body">
			<br>
			<?php
			$un=$_SESSION['un'];
			if(!$un)
			{
				header("Location:index.php");
			}
			?>

			 <h1>Donor List</h1>
			 <center><div id="form">
			 	<table>
			 		<tr>
			 			<td><center><b><font color="black">Name</font></b></center></td>
			 			<td><center><b><font color="black">Father's Name</font></b></center></td>
			 			<td><center><b><font color="black">Address</font></b></center></td>
			 			<td><center><b><font color="black">City</font></b></center></td>
			 			<td><center><b><font color="black">Age</font></b></center></td>
			 			<td><center><b><font color="black">Blood Group</font></b></center></td>
			 			<td><center><b><font color="black">Email</font></b></center></td>
			 			<td><center><b><font color="black">Mobile No</font></b></center></td>
			 		</tr>

			 		<?php
			 		$q=$db->query("SELECT * FROM donor_registration");
			 		while($rl=$q->fetch(PDO::FETCH_OBJ))
			 		{
			 			?>
			 		<tr>
			 			<td><center><?= $rl->name; ?></center></td>
			 			<td><center><?= $rl->fname; ?></center></td>
			 			<td><center><?= $rl->address; ?></center></td>
			 			<td><center><?= $rl->city; ?></center></td>
			 			<td><center><?= $rl->age; ?></center></td>
			 			<td><center><?= $rl->bgroup; ?></center></td>
			 			<td><center><?= $rl->email; ?></center></td>
			 			<td><center><?= $rl->mno; ?></center></td>
			 		</tr>
			 		
			 		<?php

			 		}
			 		?>
			 		

			 		
			 	</table>
			 </div></center>

		</div>
		<div id="footer"><h4 align="center">Copyright@ourproject</h4>
<p align="center"><a href="logout.php"><font color="white">Logout</font></a></p>
		</div>


	</div>
</div>
</body>
</html>